class Node {
  
  private boolean empty;  //Check if it is an empty block
  private int x, y;
  private String label;
  boolean visited=false;
  public Node parent=null;


 	public Node(int x, int y, boolean e) {
 	  this.x=x;
 	  this.y=y;
 	  this.empty=e;
 	  label="";

 	}
 	
 	public int getX() {
 	  return x;
 	}

 	public int getY() {
 	  return y;
 	}
 	
 	public void setEmpty(boolean e) {
 	  this.empty=e;
 	}
 	
 	public boolean isEmpty() {
 	  return empty;
 	}
 	
 	public void setLabel(String l) {
 		label=l;
 	}
 	
 	public String getLabel() {
 		return label;
 	}
 	public static boolean isFree(int xx,int yy,int dim,Node[][] n) {
 		if ((xx>0)&&(xx<dim)&&(yy>0)&&(yy<dim)) {
 			if (n[xx][yy].visited)
 				return false;
 			return true;
 		}
 		return false;
 			
 	}
 	
}
  
