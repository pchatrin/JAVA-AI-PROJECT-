import java.io.*;
import javax.swing.*;

import java.awt.*;
import java.util.*;

public class RandomMouse {

	static final int delay = 200; // Sleep time for thread
	static Stack<Node> allCheese = new Stack<>();
	static LinkedList<Node> visitedNode = new LinkedList<Node>();
	private static Node tempCheese;
	static int count = 0;

	private static int curX;
	private static int curY;

	// ***********************************************************
	public static void main(String args[]) throws Exception {

		UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		JFrame frame = new JFrame("Tom & Jerry");
		TextField textField = new TextField();
		Panel panel;
		JButton[][] button; // Displaying buttons on the frame
		Node[][] node; // Nodes representing blocks
		ImageIcon jerry = new ImageIcon("jerry.gif");
		ImageIcon cheese = new ImageIcon("cheese.gif");
		ImageIcon brick = new ImageIcon("brick.gif");
		ImageIcon winner = new ImageIcon("winner.gif");

		int numMove = 0; // Number of mouse moves
		int numCheese = 0; // Number of cheese
		int dim = 0; // Board dimension
		int cheeseX = -1, cheeseY = -1; // Cheese location
		int begin = -1, end = -1;
		int x = -1, y = -1;

		// *********************************************************
		// Open data file and read board dimension
		BufferedReader br = new BufferedReader(new FileReader(args[0]));
		String line, text = "";
		while ((line = br.readLine()) != null)
			text += line.toLowerCase();
		br.close();
		// Read board dimension
		if ((begin = text.indexOf("<board-size>")) != -1) {
			begin += 12;
			if ((end = text.indexOf("</board-size>", begin)) != -1) {
				if (begin < end)
					dim = Integer.parseInt(text.substring(begin, end));
			}
		}

		// *********************************************************
		// Initialize all components
		frame.setLayout(new BorderLayout());
		frame.add(textField, BorderLayout.NORTH);
		button = new JButton[dim][dim];
		node = new Node[dim][dim];
		panel = new Panel(new GridLayout(dim, dim));
		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < dim; j++) {
				button[i][j] = new JButton();
				button[i][j].setBackground(Color.WHITE);
				panel.add(button[i][j]);
				node[i][j] = new Node(i, j, true);
			}
		}
		frame.add(panel, BorderLayout.CENTER);

		// *********************************************************
		// Set locations for mouse and cheese
		button[0][0].setIcon(jerry);
		end = 0;
		while ((begin = text.indexOf("cheese-location", end)) != -1) {
			begin = text.indexOf("x=\"", begin) + 3;
			end = text.indexOf("\"", begin);
			cheeseX = Integer.parseInt(text.substring(begin, end));
			begin = text.indexOf("y=\"", begin) + 3;
			end = text.indexOf("\"", begin);
			cheeseY = Integer.parseInt(text.substring(begin, end));
			node[cheeseX][cheeseY].setLabel("cheese");
			button[cheeseX][cheeseY].setIcon(cheese);
			allCheese.add(node[cheeseX][cheeseY]);
			numCheese++;
		}

		// *********************************************************
		// Set brick locations
		begin = 0;
		while ((begin = text.indexOf("brick-location", begin)) != -1) {
			begin = text.indexOf("x=\"", begin) + 3;
			end = text.indexOf("\"", begin);
			if (begin < end)
				x = Integer.parseInt(text.substring(begin, end));
			begin = text.indexOf("y=\"", begin) + 3;
			end = text.indexOf("\"", begin);
			if (begin < end)
				y = Integer.parseInt(text.substring(begin, end));
			button[x][y].setIcon(brick);
			node[x][y].setEmpty(false);
		}

		// *********************************************************
		// Ensure application exits when window is closed
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack(); // Layout components in window
		frame.setVisible(true); // Show window
		frame.setSize(dim * 60, (dim * 60) + 40); // Set default frame size

		// *************************************************************
		// IMPLEMENTING MOUSE MOVE: Random Search
		boolean found = false;
		curX = curY = 0; // Current mouse location
		int prevX = 0, prevY = 0; // Previous mouse location
		Thread.sleep(delay);
		while (!found) {
			do {
				sort(allCheese);
				tempCheese = allCheese.peek();
				int distance = 1000000;
				int temp, tempX = -1, tempY = -1;
				for (int i = 1; i >= -1; i--) {
					for (int j = 1; j >= -1; j--) {
						if (!(i == 0 && j == 0)) {
							x = curX + i;
							y = curY + j;
							if (((x >= 0) && (x < dim)) && ((y >= 0) && (y < dim)) && (node[x][y].isEmpty() == true)
									&& !((x == prevX) && (y == prevY)) && !visitedNode.contains(node[x][y])) {
								temp = Math.abs(x - tempCheese.getX()) + Math.abs(y - tempCheese.getY());
								if (temp < distance) {
									distance = temp;
									tempX = x;
									tempY = y;
								}
							}
						}
					}
				}
				x = tempX;
				y = tempY;
				if ((x == curX) && (y == curY) || (x == -1) && (y == -1)) {
					x = prevX;
					y = prevY;
				}
				if (!visitedNode.contains(node[x][y])) {
					visitedNode.add(node[x][y]);
					count = 0;
				} else {
					count++;
				}
				if (count > 0) {
					return;
				}

			} while ((x < 0) || (x >= dim) || (y < 0) || (y >= dim) || (!node[x][y].isEmpty())
					|| ((x == curX) && (y == curY)));

			button[curX][curY].setIcon(null); // Delete the mouse from the current block
			button[x][y].setIcon(jerry); // Move the mouse to a new block
			prevX = curX;
			prevY = curY;
			curX = x;
			curY = y;
			numMove++;
			textField.setText("Number of moves = " + numMove);

			// Check if the mouse has found the cheese
			if (node[curX][curY].getLabel() == "cheese") {
				allCheese.remove(node[curX][curY]);
				node[curX][curY].setLabel("");
				visitedNode = new LinkedList<Node>();
				numCheese--;
				if (numCheese == 0) {
					button[curX][curY].setIcon(winner);
					found = true;
				} else
					button[curX][curY].setIcon(jerry);
			}
			Thread.sleep(delay); // Slow down the mouse
		}
	}
	public static int compare(Node a,Node b) {
		Double tempA,tempB;
		tempA=(double) (Math.abs(curX - a.getX()) + Math.abs(curY - a.getY()));;
		tempB=(double) (Math.abs(curX - b.getX()) + Math.abs(curY - b.getY()));;
		return tempB.compareTo(tempA);
	}
	private static void sort(Stack<Node> allCheese) {
		for(int i=allCheese.size()-1;i>=0;i--) {
			for(int j=0;j<i;j++) {
				if(compare(allCheese.get(j),allCheese.get(j+1))==1) {
					Node temp=allCheese.get(j);
					allCheese.set(j,allCheese.get(j+1));
					allCheese.set(j+1,temp);
				}
			}
		}
		
	}
	
}
