import java.util.*;
public class findPath {
	static Stack<Node> path=new Stack<Node>();
	static Queue<Node> q = new LinkedList<Node>();
	
	public static Stack<Node> pathBFS(Node startNode,Node endNode,Node[][] n,int dim) {
		Node[][] node;
		node=n.clone();
	    q.add(node[startNode.getX()][startNode.getY()]);
	    while(!q.isEmpty()) {
	    		Node p=q.remove();
	    		int x=p.getX();
	    		int y=p.getY();
	    		
	    		if ((x==endNode.getX())&&(y==endNode.getY())) {
	    			break;
	    		}
	    		if ((x+1>0)&&(x+1<dim)) {
	    			if(!node[x+1][y].visited) {
	    				node[x+1][y].visited=true;
	    			if (node[x+1][y].isEmpty()) {
	    				node[x+1][y].parent=node[x][y];
	    				q.add(node[x+1][y]);
	    			}
	    			}
	    		}
	    		if ((x+1>0)&&(x+1<dim)&&(y+1>0)&&(y+1<dim)) {
	    			if(!node[x+1][y+1].visited) {
	    				node[x+1][y+1].visited=true;
	    			if (node[x+1][y+1].isEmpty()) {
	    				node[x+1][y+1].parent=node[x][y];
	    				q.add(node[x+1][y+1]);
	    			}
	    			}
	    		}
	        		if ((y+1>0)&&(y+1<dim)) {
	        			if(!node[x][y+1].visited) {
	        				node[x][y+1].visited=true;
	    			if (node[x][y+1].isEmpty()) {
	    				node[x][y+1].parent=node[x][y];
	    				q.add(node[x][y+1]);
	    			}
	    			}
	    		}
	        		if ((x-1>0)&&(x-1<dim)&&(y+1>0)&&(y+1<dim)) {
	        			if(!node[x-1][y+1].visited) {
	        				node[x-1][y+1].visited=true;
	    			if (node[x-1][y+1].isEmpty()) {
	    				node[x-1][y+1].parent=node[x][y];
	    				q.add(node[x-1][y+1]);
	    			}
	    			}
	    		}
	        		if ((x-1>0)&&(x-1<dim)) {
	        			if(!node[x-1][y].visited) {
	        				node[x-1][y].visited=true;
	    			if (node[x-1][y].isEmpty()) {
	    				node[x-1][y].parent=node[x][y];
	    				q.add(node[x-1][y]);
	    			}
	    			}
	    		}
	        		if ((x-1>0)&&(x-1<dim)&&(y-1>0)&&(y-1<dim)) {
	        			if(!node[x-1][y-1].visited) {
	        				node[x-1][y-1].visited=true;
	    			if (node[x-1][y-1].isEmpty()) {
	    				node[x-1][y-1].parent=node[x][y];
	    				q.add(node[x-1][y-1]);
	    			}
	    			}
	    		}
	        		if ((y-1>0)&&(y-1<dim)) {
	        			if(!node[x][y-1].visited) {
	        				node[x][y-1].visited=true;
	    			if (node[x][y-1].isEmpty()) {
	    				node[x][y-1].parent=node[x][y];
	    				q.add(node[x][y-1]);
	    			}
	    			}
	    		}  		
	        		if ((x+1>0)&&(x+1<dim)&&(y-1>0)&&(y-1<dim)) {
	        			if(!node[x+1][y-1].visited) {
	        				node[x+1][y-1].visited=true;
	    			if (node[x+1][y-1].isEmpty()) {
	    				node[x+1][y-1].parent=node[x][y];
	    				q.add(node[x+1][y-1]);
	    			}
	    			}
	    		}	
	     }
	    Stack<Node> pa=new Stack<Node>();
	    if (endNode.parent==null) {
	    	System.out.println("No solution for this maze");
	    	return pa;
	    }
	    Node temp;
	    temp=endNode;
	    
	    while (temp.parent!=null) {
	    		pa.push(temp);
	    		temp=temp.parent;

	    }
		return pa;
	}
	

	
	
	public static Stack<Node> nearestNode(Node curNode,LinkedList<Node> cheeseLocation,Node[][] n,int dim) {
		Stack<Node> nearestPath=new Stack<Node>();
		Node temp;
		Stack<Node> tempPath;
		int length=100;
		LinkedList<Node> tt=new LinkedList<Node>(cheeseLocation);
		while(!tt.isEmpty()) {
			temp=tt.remove();
			tempPath=findPath.pathBFS(curNode,temp,n,dim);
			System.out.println(tempPath.size());
			if (tempPath.size()<length)
				length=tempPath.size();
				nearestPath=tempPath;			
		}
		
		return nearestPath;
		
	}
	

}
