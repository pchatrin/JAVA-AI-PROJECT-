import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.util.*;

public class RandomMouse {
  
  static final int delay=400;  //Sleep time for thread

  //***********************************************************
  public static void main(String args[]) throws Exception {

    UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
    JFrame frame=new JFrame("Tom & Jerry");
    TextField textField=new TextField();
    Panel panel;
    JButton[][] button;  //Displaying buttons on the frame
    Node[][] node;       //Nodes representing blocks
    ImageIcon jerry=new ImageIcon("jerry.gif");    
    ImageIcon cheese=new ImageIcon("cheese.gif");   
    ImageIcon brick=new ImageIcon("brick.gif");
    ImageIcon winner=new ImageIcon("winner.gif");      

    int numMove=0;               //Number of mouse moves
    int numCheese=0;             //Number of cheese
    int dim=0;                   //Board dimension
    int cheeseX=-1, cheeseY=-1;  //Cheese location
    int begin=-1, end=-1;
    int x=-1, y=-1; 

    //*********************************************************
    //Open data file and read board dimension
    BufferedReader br=new BufferedReader(new FileReader(args[0]));
    String line, text="";
    while((line=br.readLine())!=null)
      text+=line.toLowerCase();
    br.close();
    //Read board dimension
    if((begin=text.indexOf("<board-size>"))!=-1) {
      begin+=12;
      if((end=text.indexOf("</board-size>", begin))!=-1) {
        if(begin<end)
          dim=Integer.parseInt(text.substring(begin,end));
      }
    }
    
    //*********************************************************
    //Initialize all components
    frame.setLayout(new BorderLayout());
    frame.add(textField,BorderLayout.NORTH);
    button=new JButton[dim][dim];
    node=new Node[dim][dim];
    panel=new Panel(new GridLayout(dim,dim));
    for(int i=0; i<dim; i++) {
      for(int j=0; j<dim; j++) {
        button[i][j] = new JButton();
        button[i][j].setBackground(Color.WHITE);
        panel.add(button[i][j]);
        node[i][j]=new Node(i, j, true);
      }
    }
    frame.add(panel,BorderLayout.CENTER);
    
    //*********************************************************
    //Set locations for mouse and cheese
    button[0][0].setIcon(jerry);
    end=0;
    LinkedList<Node> cheeseLocation=new LinkedList<Node>();
    while((begin=text.indexOf("cheese-location", end))!=-1) {
      begin=text.indexOf("x=\"", begin)+3;
      end=text.indexOf("\"", begin);
      cheeseX=Integer.parseInt(text.substring(begin,end));
      begin=text.indexOf("y=\"", begin)+3;
      end=text.indexOf("\"", begin);
      cheeseY=Integer.parseInt(text.substring(begin,end));
      node[cheeseX][cheeseY].setLabel("cheese");
      button[cheeseX][cheeseY].setIcon(cheese);
      cheeseLocation.add(node[cheeseX][cheeseY]);
      numCheese++;
    }
    

    //*********************************************************
    //Set brick locations
    begin=0;
    while((begin=text.indexOf("brick-location", begin))!=-1) {
      begin=text.indexOf("x=\"", begin)+3;
      end=text.indexOf("\"", begin);
      if(begin<end)
        x=Integer.parseInt(text.substring(begin,end));
      begin=text.indexOf("y=\"", begin)+3;
      end=text.indexOf("\"", begin);
      if(begin<end)
        y=Integer.parseInt(text.substring(begin,end));
      button[x][y].setIcon(brick);
      node[x][y].setEmpty(false);
    }

    //*********************************************************
    //Ensure application exits when window is closed
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.pack();                        //Layout components in window
    frame.setVisible(true);              //Show window
    frame.setSize(dim*60,(dim*60)+40);   //Set default frame size
    
    //*************************************************************
    //IMPLEMENTING MOUSE MOVE: Random Search
    int curX=0, curY=0;    //Current mouse location
    int prevX=0, prevY=0;  //Previous mouse location    
    Thread.sleep(delay);
    Stack<Node> path=new Stack<Node>();
  
    while (!cheeseLocation.isEmpty()) {
   
    		 path=findPath.nearestNode(node[curX][curY], cheeseLocation, node, dim);
    		cheeseLocation.remove(path.firstElement());
    		while (!path.isEmpty()) {
    		Node p=path.pop();
    		curX=p.getX();
    		curY=p.getY();
    		button[prevX][prevY].setIcon(null);  //Delete the mouse from the current block
    		button[curX][curY].setIcon(jerry);       //Move the mouse to a new block
    		prevX=curX;
    		prevY=curY;
    		numMove++;
    		textField.setText("Number of moves = " + numMove);

      //Check if the mouse has found the cheese
    		if(node[curX][curY].getLabel()=="cheese") {
    	    	  numCheese--;
    	    	  if(numCheese==0) {
    	    		  button[curX][curY].setIcon(winner);
    	    	  }
    	    	  else
    	    		  button[curX][curY].setIcon(jerry);        
    	      }
    Thread.sleep(delay);  //Slow down the mouse
    		}
    		

   

    
    		
    		    		
    }

      
    
  }
} 

